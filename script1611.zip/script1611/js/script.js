var imagem = document.getElementById("lamp");
imagem.addEventListener("click",trocarImagem);
function trocarImagem(){
    if(imagem.src.match("on")){
        imagem.src = "img/pic_bulboff.gif";
    }
    else{
        imagem.src = "img/pic_bulbon.gif";
    }
}